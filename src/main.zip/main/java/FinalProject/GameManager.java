package FinalProject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Controls the trivia game logic: question loading, scoring, and progression.
 */
public class GameManager {

    private List<Question> questions;
    private int currentIndex;
    private int score;
    private int maxQuestions;

    public GameManager() {
        this.questions = new ArrayList<>();
        this.currentIndex = 0;
        this.score = 0;
        this.maxQuestions = 10; // adjustable
        loadHarryPotterQuestions();
    }

    /**
     * Loads Harry Potter trivia questions into the game.
     */
    private void loadHarryPotterQuestions() {
        questions.add(new MultipleChoiceQuestion(
                "What house at Hogwarts does Harry Potter belong to?",
                new String[]{"Hufflepuff", "Ravenclaw", "Gryffindor", "Slytherin"},
                "Gryffindor",
                "Houses",
                1,
                "Harry was sorted into Gryffindor in his first year."
        ));

        questions.add(new MultipleChoiceQuestion(
                "What position does Harry play on his Quidditch team?",
                new String[]{"Keeper", "Beater", "Chaser", "Seeker"},
                "Seeker",
                "Quidditch",
                1,
                "Harry is the Seeker for Gryffindor."
        ));

        questions.add(new MultipleChoiceQuestion(
                "What is the name of Harry's pet owl?",
                new String[]{"Errol", "Hedwig", "Crookshanks", "Scabbers"},
                "Hedwig",
                "Animals",
                1,
                "Hedwig was given to Harry as a birthday gift by Hagrid."
        ));

        questions.add(new MultipleChoiceQuestion(
                "Who kills Professor Dumbledore?",
                new String[]{"Lord Voldemort", "Bellatrix Lestrange", "Draco Malfoy", "Severus Snape"},
                "Severus Snape",
                "Plot",
                2,
                "Snape kills Dumbledore at the end of Half-Blood Prince."
        ));

        questions.add(new MultipleChoiceQuestion(
                "What object must be caught to end a Quidditch match?",
                new String[]{"Quaffle", "Bludger", "Golden Snitch", "Broomstick"},
                "Golden Snitch",
                "Quidditch",
                1,
                "Catching the Golden Snitch ends the match."
        ));

        questions.add(new MultipleChoiceQuestion(
                "What magical ability does Harry share with Voldemort?",
                new String[]{"Invisibility", "Parseltongue", "Apparition", "Legilimency"},
                "Parseltongue",
                "Magic",
                2,
                "Both can speak Parseltongue, the language of snakes."
        ));

        questions.add(new MultipleChoiceQuestion(
                "Who was the Half-Blood Prince?",
                new String[]{"James Potter", "Sirius Black", "Severus Snape", "Tom Riddle"},
                "Severus Snape",
                "Characters",
                2,
                "The Half-Blood Prince was Severus Snape."
        ));

        questions.add(new MultipleChoiceQuestion(
                "What form does Harry's Patronus take?",
                new String[]{"Phoenix", "Stag", "Otter", "Wolf"},
                "Stag",
                "Magic",
                2,
                "Harry’s Patronus is a stag, like his father’s Animagus form."
        ));

        questions.add(new MultipleChoiceQuestion(
                "What does the Imperius Curse do?",
                new String[]{"Kills instantly", "Tortures painfully", "Controls a person's actions", "Heals wounds"},
                "Controls a person's actions",
                "Curses",
                3,
                "The Imperius Curse allows the caster to control the victim."
        ));

        questions.add(new MultipleChoiceQuestion(
                "Who is the heir of Slytherin?",
                new String[]{"Draco Malfoy", "Tom Riddle", "Severus Snape", "Harry Potter"},
                "Tom Riddle",
                "Plot",
                3,
                "Tom Riddle (Voldemort) was the true heir of Slytherin."
        ));

        Collections.shuffle(questions);
    }

    public Question getNextQuestion() {
        if (currentIndex < questions.size()) {
            return questions.get(currentIndex++);
        }
        return null;
    }

    public void incrementScore() {
        score++;
    }

    public int getScore() {
        return score;
    }

    public boolean hasMoreQuestions() {
        return currentIndex < maxQuestions && currentIndex < questions.size();
    }
}
