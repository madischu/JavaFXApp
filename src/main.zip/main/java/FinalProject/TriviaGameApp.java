package FinalProject;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Main JavaFX application class for the Trivia Game.
 * Displays the main menu with difficulty options and navigates between screens.
 */

public class TriviaGameApp extends Application {
    private Stage primaryStage;
    private GameManager gameManager;
    private String currentDifficulty;
    private PlayerProfile playerProfile = new PlayerProfile("Player1");

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Trivia Game");
        primaryStage.setScene(createMainMenuScene());
        primaryStage.show();
    }

    private Scene createMainMenuScene() {
        Label title = new Label("Trivia Game");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        Button easyBtn = new Button("Easy");
        Button mediumBtn = new Button("Medium");
        Button hardBtn = new Button("Hard");

        easyBtn.setPrefWidth(100);
        mediumBtn.setPrefWidth(100);
        hardBtn.setPrefWidth(100);

        easyBtn.setOnAction(e -> startGame("Easy"));
        mediumBtn.setOnAction(e -> startGame("Medium"));
        hardBtn.setOnAction(e -> startGame("Hard"));

        HBox difficultyBox = new HBox(20, easyBtn, mediumBtn, hardBtn);
        difficultyBox.setAlignment(Pos.CENTER);

        Button homeBtn = new Button("User Home");
        Button instructionsBtn = new Button("Instructions");
        instructionsBtn.setOnAction(e -> primaryStage.setScene(createInstructionsScene()));

        homeBtn.setOnAction(e -> {
            UserHomeScreen homeScreen = new UserHomeScreen(
                primaryStage,
                playerProfile,
                () -> startGame(currentDifficulty != null ? currentDifficulty : "Easy"),
                () -> primaryStage.setScene(createMainMenuScene())
            );
            primaryStage.setScene(homeScreen.getScene());
        });

        VBox mainBox = new VBox(20, title, difficultyBox, homeBtn, instructionsBtn);
        mainBox.setAlignment(Pos.CENTER);
        mainBox.setPadding(new Insets(40));

        BorderPane root = new BorderPane();
        root.setCenter(mainBox);

        return new Scene(root, 500, 400);
    }

    private Scene createGameScene() {
        Question question = gameManager.getNextQuestion();
        if (question == null) {
            int difficultyNum = 1;
            if ("Medium".equalsIgnoreCase(currentDifficulty)) difficultyNum = 2;
            else if ("Hard".equalsIgnoreCase(currentDifficulty)) difficultyNum = 3;
            playerProfile.addScore(new ScoreRecord(gameManager.getScore(), difficultyNum));

            Label endLabel = new Label("Game Over! Your score: " + gameManager.getScore());
            Button backBtn = new Button("Back to Menu");
            backBtn.setOnAction(e -> primaryStage.setScene(createMainMenuScene()));
            VBox layout = new VBox(20, endLabel, backBtn);
            layout.setAlignment(Pos.CENTER);
            return new Scene(layout, 500, 400);
        }

        Label questionLabel = new Label(question.getQuestionText());
        questionLabel.setWrapText(true);
        questionLabel.setStyle("-fx-font-size: 18px;");

        Button[] optionButtons = new Button[question.getOptions().length];
        VBox optionsBox = new VBox(10);
        optionsBox.setAlignment(Pos.CENTER);

        for (int i = 0; i < question.getOptions().length; i++) {
            String option = question.getOptions()[i];
            optionButtons[i] = new Button(option);
            optionButtons[i].setPrefWidth(200);
            optionButtons[i].setOnAction(e -> {
                boolean correct = question.checkAnswer(option);
                if (correct) {
                    gameManager.incrementScore();
                }
                primaryStage.setScene(createGameScene());
            });
            optionsBox.getChildren().add(optionButtons[i]);
        }

        Label scoreLabel = new Label("Score: " + gameManager.getScore());
        scoreLabel.setStyle("-fx-font-size: 14px;");

        Button backBtn = new Button("Back to Menu");
        backBtn.setOnAction(e -> primaryStage.setScene(createMainMenuScene()));

        VBox layout = new VBox(20, questionLabel, optionsBox, scoreLabel, backBtn);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(30));

        return new Scene(layout, 500, 400);
    }

    private Scene createInstructionsScene() {
        Label label = new Label("Instructions:\nAnswer questions to gain points.\nSelect difficulty to start.");
        Button backBtn = new Button("Back to Menu");
        backBtn.setOnAction(e -> primaryStage.setScene(createMainMenuScene()));

        VBox layout = new VBox(20, label, backBtn);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));

        return new Scene(layout, 500, 400);
    }

    private void startGame(String difficulty) {
        this.currentDifficulty = difficulty;
        this.gameManager = new GameManager();
        primaryStage.setScene(createGameScene());
    }
}
